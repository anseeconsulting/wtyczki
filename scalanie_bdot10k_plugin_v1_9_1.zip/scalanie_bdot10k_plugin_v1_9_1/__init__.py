def classFactory(iface):
    from .plugin import BdotZipMergePlugin
    return BdotZipMergePlugin(iface)
