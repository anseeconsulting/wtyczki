# original source code changed by rewriting import statements
"""
    babel.messages
    ~~~~~~~~~~~~~~

    Support for ``gettext`` message catalogs.

    :copyright: (c) 2013-2022 by the Babel Team.
    :license: BSD, see LICENSE for more details.
"""

from umweltaspekte._vendor.babel.messages.catalog import *
