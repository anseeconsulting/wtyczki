import os.path, math, ntpath, re
import processing
import csv

from qgis.core import (
  QgsGeometry, 
  QgsPoint,
  QgsField,
  QgsFields,
  QgsFeature,
  QgsWkbTypes,
  QgsProject,
  QgsVectorLayer,
  QgsVectorLayer,
  QgsCoordinateReferenceSystem,
  QgsCoordinateTransform,
  QgsSpatialIndex,
  QgsProcessing,
  QgsProcessingContext,
  QgsFeatureIterator,
  QgsProcessingUtils

)
from PyQt5.QtCore import *

#Funkcje wspomagające
def kmFormat(km):
    km_format = str(math.floor(km/1000)) + '+' + str(int(km%1000)).rjust(3,'0')
    return km_format

class Layer:
    def __init__(self, layer):
        self.layer = layer
        self.pt = QgsPoint()
        self.prefix = ''
        self.result_paths_and_prefix = []

    def getLayer(self):
        return self.layer

    def getPath(self):
        print(self.layer.source())
        return self.layer.source()

    def makeSpatialIndex(self):
        spIndex = QgsSpatialIndex()
        for feat in self.layer.getFeatures():
            spIndex.insertFeature(feat)
        return spIndex

    def czyPolygon(self):
        if self.layer.geometryType() == QgsWkbTypes.PolygonGeometry:
            polygon = True
        else:
            polygon = False
        return polygon

    def makePrefix(self, prefix):
        self.prefix = prefix
    # def transformCRS(self):

    # def addResultPath(self, path):
    #     self.result_paths.append(path)

    def addResultPathAndPrefix(self, path, prefix):
        self.result_paths_and_prefix.append([path, prefix])

    def getResultPathsAndPrefix(self):
        return self.result_paths_and_prefix

    # def getResultPaths(self):
    #     return self.result_paths

    def getPrefix(self):
        return self.prefix

    def setPrefix(self, prefix):
        self.prefix = prefix

    def distansStrona(self, os):
        """
        Return error code
        ------------------
        Uzupełnia informację o odległość i stronę
        """

        self.error = 0
        self.layer.startEditing()
        line_feats = [ feat for feat in os.getLayer().getFeatures() ] 
        layer_feats = [ feat for feat in self.layer.getFeatures() ]

        for feat in layer_feats:
            if feat.geometry() is None:
                self.error = 4 #pusta geometria w warstwie przecinanej
                return self.error

            dist_od_osi = 999999999
            pos = ''
            pt = QgsPoint()

            for line_feat in line_feats:
                if line_feat.geometry() is None:
                    self.error = 3 #pusta geometria osi
                    return self.error

                feat_to_point_geom_temp = line_feat.geometry().nearestPoint(feat.geometry()) #najblizszy punkt na osi
                feat_to_point_geom_feature_temp = feat.geometry().nearestPoint(line_feat.geometry()) #najblizszy punkt na obiekcie
                dist_od_osi_temp = QgsGeometry.distance(feat_to_point_geom_temp, feat.geometry())
                if dist_od_osi_temp  < dist_od_osi:
                    pt = feat_to_point_geom_feature_temp.asPoint()

                    dist_od_osi = round(dist_od_osi_temp,1)

                    point_in_line = line_feat.geometry().closestSegmentWithContext(pt)[3] #numer 3 pokazuje która strona, numer 1 daje punkt

                    if point_in_line > 0:
                        pos = 'prawa'
                    elif point_in_line < 0:
                        pos = 'lewa'
                    else:
                        pos = 'na osi'
                    if line_feat.geometry().crosses(feat.geometry()) or line_feat.geometry().intersects(feat.geometry()):
                        pos = 'na osi'

            self.pt = pt
            idx_dist_od_osi = self.layer.fields().lookupField('dist_od_osi')
            feat[idx_dist_od_osi] = round(float(dist_od_osi),3)

            idx_strona = self.layer.fields().lookupField('strona')
            feat[idx_strona] = pos

            self.layer.updateFeature( feat )

        self.layer.commitChanges()
        return self.error

    def przeciecia(self, km, os, pas, km_checked, os_checked, pas_checked, kmfield):
        """
        Return error code
        ------------------
        Uzupełnia informację o kilometrażu, odległości i powierzchni przecięć
        """
        self.layer.startEditing()
        crs92 = "EPSG:2180"
        spIndex = km.makeSpatialIndex()
        layer_feats = [ feat for feat in self.layer.getFeatures() ]
        i=0
        for feat in layer_feats:
            if pas_checked:
                obszar_fts = pas.getLayer().getFeatures()
            else:
                obszar_fts = QgsFeatureIterator()

            if os_checked:
                os_fts = os.getLayer().getFeatures()
            else:
                os_fts = []

            pos_zakres = 'poza zakresem inwestycji'

            geoms = QgsGeometry.fromWkt('GEOMETRYCOLLECTION()')
            for feature in os_fts:
                geom = feature.geometry()
                geoms = geoms.combine(geom)

            dist_to_pas = []
            area = 0

            #tworzy nową warstwę na przecięcia
            przeciecia_fts = QgsVectorLayer(QgsWkbTypes.displayString(QgsWkbTypes.Point)+"?crs="+crs92, "przecięcia", "memory")
            przeciecia_fts.startEditing()
            fieldid = QgsField("id", QVariant.Int)
            fieldids = QgsFields()
            fieldids.append(fieldid)
            przeciecia_fts.addAttribute(fieldid)

            intersections_fts = []
            #pętla po obszarach
            if not obszar_fts.isValid():
                feat_ring = feat.geometry().convertToType(1,False) #wybranie granic poligonów inwentaryzacji w celu przecięć

                if not feat.geometry().intersection(geoms.buffer(0.01,50)).isEmpty():
                    intersections_fts.append(feat.geometry().intersection(geoms.buffer(0.01,50))) #dodanie oryginalnych obiektów do listy z przecięciami jeśli nie analizujemy pasa
                #dodanie oryginalnych obiektów do listy z przecięciami jeśli nie analizujemy pasa
                przeciecia_pts = feat_ring.intersection(geoms.convertToType(5,False)) #uzyskanie punktów przecięcia

                if not (przeciecia_pts.isEmpty()):
                    points = przeciecia_pts.asMultiPoint() #################### możliwy błąd typu osi
                    for point in points:
                        i+=1
                        new_feature = QgsFeature(fieldids)
                        new_feature.setGeometry(QgsPoint(point))
                        new_feature.setAttribute(0,i)
                        przeciecia_fts.addFeature(new_feature)
                else:
                    new_feature = QgsFeature(fieldids)
                    if km_checked and os_checked:
                        new_feature.setGeometry(QgsPoint(feat.geometry().nearestPoint(geoms).asPoint()))
                        new_feature.setAttribute(0,i)
                        przeciecia_fts.addFeature(new_feature)

                    else:
                        if not obszar_ft.geometry().isNull():
                            new_feature.setGeometry(QgsPoint(feat.geometry().nearestPoint(obszar_ft.geometry().buffer(0.01,50)).asPoint()))
                            new_feature.setAttribute(0,i)
                            przeciecia_fts.addFeature(new_feature)


            for obszar_ft in obszar_fts:
                if obszar_ft.geometry().buffer(0.01,50).crosses(feat.geometry()) or obszar_ft.geometry().buffer(0.01,50).intersects(feat.geometry()) or obszar_ft.geometry().buffer(0.01,50).contains(feat.geometry()):
                    pos_zakres = 'w zakresie inwestycji' #modyfikacja pola pozycja
                dist_to_pas.append(float(QgsGeometry.distance(obszar_ft.geometry().buffer(0.01,50),feat.geometry()))) #dodanie do listy odległości w celu wybrania najmniejszej

                if self.czyPolygon():
                    feat_ring = feat.geometry().convertToType(1,False) #wybranie granic poligonów inwentaryzacji w celu przecięć
                    przeciecia_pts = QgsGeometry() #warstwa z punktami przecięcia
                    if pas_checked:
                        przeciecia = feat.geometry().intersection(obszar_ft.geometry().buffer(0.01,50))
                        area += przeciecia.area() #dodanie do liczby z powierzchni przecięcia danego fragmentu
                        obszar_ring = obszar_ft.geometry().buffer(0.01,50).convertToType(1,False)

                        if not przeciecia.isEmpty():
                            intersections_fts.append(przeciecia) #dodanie obiektów do listy z przecięciami

                        przeciecia_pts = feat_ring.intersection(obszar_ring) #uzyskanie punktów przecięcia
                    else:
                        intersections_fts.append(feat.geometry().buffer(0.01,50)) #dodanie oryginalnych obiektów do listy z przecięciami jeśli nie analizujemy pasa
                        przeciecia_pts = feat_ring.intersection(geoms.geometry().buffer(0.01,50))#.buffer(0.01,50).convertToType(1,False)) #uzyskanie punktów przecięcia
                        ############### doddć przecięcia z osią!!!!
                        # przeciecia_pts = feat_ring.intersection(os) #uzyskanie punktów przecięcia

                    if not (przeciecia_pts.isEmpty()):
                        points = przeciecia_pts.asMultiPoint()
                        for point in points:
                            i+=1
                            new_feature = QgsFeature(fieldids)
                            new_feature.setGeometry(QgsPoint(point))
                            new_feature.setAttribute(0,i)
                            przeciecia_fts.addFeature(new_feature)
                    else:
                        new_feature = QgsFeature(fieldids)
                        if km_checked and os_checked:
                            new_feature.setGeometry(QgsPoint(feat.geometry().nearestPoint(geoms).asPoint()))
                            new_feature.setAttribute(0,i)
                            przeciecia_fts.addFeature(new_feature)

                        else:
                            if not obszar_ft.geometry().isNull():
                                new_feature.setGeometry(QgsPoint(feat.geometry().nearestPoint(obszar_ft.geometry().buffer(0.01,50)).asPoint()))
                                new_feature.setAttribute(0,i)
                                przeciecia_fts.addFeature(new_feature)



            przeciecia_fts.commitChanges()

            przeciecia_km = [[0]]
            przeciecia_km[0].clear()
            przeciecie_km_str = ''

            if self.czyPolygon():
                idx_powierzchnia = self.layer.fields().lookupField('powierzchnia')
                feat[idx_powierzchnia] = round(feat.geometry().area(),3)
                if pas_checked:
                    idx_powierzchnia_przec = self.layer.fields().lookupField('pow_prze')
                    feat[idx_powierzchnia_przec] = round(area,3)
                    idx_procent = self.layer.fields().lookupField('procent')
                    feat[idx_procent] = round(area*100/feat.geometry().area(),2)
                if km_checked and os_checked:
                    if  len(intersections_fts)>0:
                        liczba_obszarow = 0
                        for intersection in intersections_fts:
                            if intersection.isMultipart()==True:
                                for intersection_geom in intersection.asGeometryCollection():

                                    km_przeciec_obszaru = []
                                    for intersection_geom_pt in intersection_geom.asPolygon()[0]:
                                        nearestIds = spIndex.nearestNeighbor(intersection_geom_pt,1)
                                        km_przeciec_obszaru.append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

                                    przeciecia_km.append([])
                                    przeciecia_km[liczba_obszarow].append(min(km_przeciec_obszaru))
                                    przeciecia_km[liczba_obszarow].append(max(km_przeciec_obszaru))

                                    for przeciecia_ft in przeciecia_fts.getFeatures():
                                        if intersection_geom.contains(przeciecia_ft.geometry()) or intersection_geom.intersects(przeciecia_ft.geometry()):
                                            nearestIds = spIndex.nearestNeighbor(przeciecia_ft.geometry(),1)
                                            przeciecia_km.append([])
                                            przeciecia_km[liczba_obszarow].append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

                                    liczba_obszarow +=1
                            else:
                                for przeciecia_ft in przeciecia_fts.getFeatures():
                                    if intersection.contains(przeciecia_ft.geometry()) or intersection.intersects(przeciecia_ft.geometry()):
                                        nearestIds = spIndex.nearestNeighbor(przeciecia_ft.geometry(),1)
                                        przeciecia_km[liczba_obszarow].append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

                                    km_przeciec_obszaru = []

                                    for intersection_pt in intersection.asPolygon()[0]:

                                        nearestIds = spIndex.nearestNeighbor(intersection_pt,1)
                                        km_przeciec_obszaru.append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

                                    przeciecia_km[liczba_obszarow].append(min(km_przeciec_obszaru))
                                    przeciecia_km[liczba_obszarow].append(max(km_przeciec_obszaru))

                    else:

                        for przeciecia_ft in przeciecia_fts.getFeatures():
                            nearestIds = spIndex.nearestNeighbor(przeciecia_ft.geometry(),1)
                            przeciecia_km[0].append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

            else:
                if km_checked and os_checked:
                    nearestIds = spIndex.nearestNeighbor(feat.geometry(),1)
                    przeciecia_km[0].append(km.getLayer().getFeature(nearestIds[0]).attributes()[kmfield])

            if km_checked and os_checked:
                i=1
                idx_km = self.layer.fields().lookupField('km')

                for przeciecie_km in przeciecia_km:
                    if len(przeciecie_km)>0:
                        try:
                            przec_min = float(min(przeciecie_km))
                        except ValueError:
                            preciecie_km_obrobka = [float(przeciecie_km_.replace('+','.'))*1000 for przeciecie_km_ in przeciecie_km]
                            przec_min = min(preciecie_km_obrobka)
                        except:
                            return 8 #błąd kilometraż w złym formacie
                        try:
                            przec_max = float(max(przeciecie_km)) 
                        except ValueError:
                            preciecie_km_obrobka = [float(przeciecie_km_.replace('+','.'))*1000 for przeciecie_km_ in przeciecie_km]
                            przec_max = max(preciecie_km_obrobka)
                        except:
                            return 8 #błąd kilometraż w złym formacie
                        przeciecie_km_str+= kmFormat(przec_min)
                        if przec_min != przec_max:
                            przeciecie_km_str+= ' - '
                            przeciecie_km_str+= kmFormat(przec_max)
                        elif len(przeciecia_km) == 1 and self.layer.fields().field(idx_km).type() != QVariant.String:
                            przeciecie_km_str = przec_min
                        if len(przeciecia_km) != i: przeciecie_km_str+= ',  '
                    i+=1
                
                feat[idx_km] = str(przeciecie_km_str)

            if pas_checked:
                idx_czy_przecina = self.layer.fields().lookupField('czy_przecina')
                idx_dist_od_pasa = self.layer.fields().lookupField('dist_od_pasa')
                feat[idx_czy_przecina] = pos_zakres
                feat[idx_dist_od_pasa] = min(dist_to_pas)

            self.layer.updateFeature( feat )
                #############
        self.layer.commitChanges()
        return 0

class LoadLayers:
    def __init__(self):
        self.layers = []
        self.licznik_warstw = 0
        self.new_layers = []
        self.sp_indexes = []
        self.prefix = []
        self.context = QgsProcessingContext()

    def checkLayerValidity(self):
        wynik = 0
        layers_out = []
        for layer_klasa in self.layers:
            layer = layer_klasa.getLayer()
            #print(layer)
            if layer is not None and layer.featureCount()>0 and layer.isValid() and layer.isSpatial():
                #przebiegnij po rekordach i zobaczy czy nie ma pustej geometrii, jeśli tak to błąd
                for ft in layer.getFeatures():
                    if ft.geometry().isNull():
                        wynik = 1
                self.licznik_warstw+=1
                layers_out.append(Layer(layer))
        # jeśli nie znaleziono żadnej poprawnej warstwy, wyświetl komunikat i koniec
        if self.licznik_warstw==0:
            wynik = 2
        return wynik

    def getLayers(self):
        return self.layers

    def getLayersByPrefix(self, prefix):
        layer_by_prefix = None
        for layer_klasa in self.new_layers:

            if layer_klasa.getPrefix() == prefix:
                layer_by_prefix = layer_klasa
        return layer_by_prefix

    def getNewLayers(self):
        return self.new_layers

    def getPrefixes(self):
        return self.prefix

    def newLayers(self):
        return self.new_layers

    def loadLayer(self, layer, prefix, bufor_analizy):
        outputs = {}
        
        # Napraw geometrie
        alg_params = {
            'INPUT': layer.source(),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['NaprawGeometrie'] = processing.run('native:fixgeometries', alg_params, context=self.context, is_child_algorithm=True)

        if bufor_analizy:
            # Przytnij
            alg_params = {
                'INPUT': outputs['NaprawGeometrie']['OUTPUT'],
                'OVERLAY': bufor_analizy,
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['Przytnij'] = processing.run('native:clip', alg_params, context=self.context, is_child_algorithm=True)
        else:
            outputs['Przytnij']  = outputs['NaprawGeometrie']

        layer_napr = QgsProcessingUtils.mapLayerFromString(outputs['Przytnij']['OUTPUT'], self.context)  
        layer_napr.setName(layer.name())

        layer_save = Layer(layer_napr)
        layer_save.makePrefix(prefix)
        self.layers.append(layer_save)
        self.prefix.append(prefix)
         
    def loadLayersFromStringList(self, layersStringList, bufor_analizy):
        self.layers = []
        for laer_orygin_str in layersStringList:  #weź listę plików

            outputs = {}
            # Napraw geometrie
            alg_params = {
                'INPUT': laer_orygin_str,
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }    
            outputs['NaprawGeometrie'] = processing.run('native:fixgeometries', alg_params, context=self.context, is_child_algorithm=True)

            if bufor_analizy:
                # Przytnij
                alg_params = {
                    'INPUT': outputs['NaprawGeometrie']['OUTPUT'],
                    'OVERLAY': bufor_analizy,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                }
                outputs['Przytnij'] = processing.run('native:clip', alg_params, context=self.context, is_child_algorithm=True)
            else:
                outputs['Przytnij']  = outputs['NaprawGeometrie']

            filename = ntpath.basename(laer_orygin_str) #wyodrębnij nazwę pliku z warstwą

            layer = QgsProcessingUtils.mapLayerFromString(outputs['Przytnij']['OUTPUT'], self.context)
            layer.setName(filename)

            prefix = re.findall('\A[a-zA-Z0-9]+_', filename)[0] if len(re.findall('\A[a-zA-Z0-9]+_', filename))>0 else '_'
            layer_save = Layer(layer)
            layer_save.makePrefix(prefix)
            self.layers.append(layer_save)
            self.prefix.append(prefix)


    def makeNewLayers(self):
        self.new_layers = []
        crs92 = "EPSG:2180"
        for layer_orygin_klasa in self.layers:
            layer_orygin = layer_orygin_klasa.getLayer()
            #twórz nową warstwę do której będzie kopiować obiekty dla każdej z warstw
            layer = QgsVectorLayer(QgsWkbTypes.displayString(layer_orygin.wkbType())+"?crs="+crs92, layer_orygin.name(), "memory")

            attr = layer_orygin.dataProvider().fields().toList()
            layer.setProviderEncoding('UTF-8')
            layer.dataProvider().addAttributes(attr)

            layer.updateFields()

            #przygotuj transformację
            crs_system = layer_orygin.sourceCrs() #QgsCoordinateReferenceSystem(crs)
            crs_system92 = QgsCoordinateReferenceSystem(crs92)
            xform = QgsCoordinateTransform(crs_system, crs_system92, QgsProject.instance())
            #CRS transformation
            feats = []

            for f in layer_orygin.getFeatures():
                g = f.geometry()
                g.transform(xform)
                f.setGeometry(g)
                feats.append(f)
            # dodaj przetransformowane do układu 92 obiekty do warstwy w układzie 92
            layer.dataProvider().addFeatures(feats)

            layer_save = Layer(layer)
            layer_save.setPrefix(layer_orygin_klasa.getPrefix())
            self.new_layers.append(layer_save)

    def dodajPole(self, type, km_checked, os_checked, pas_checked, field_names, field_to_add, czy_kasowac, layer):
        if (type == 'os' and (km_checked and os_checked)) or (type == 'pas' and (pas_checked)) or (type == 'poligon') or ((type == 'poligon_pas' or type == 'poligon_pas_ocena') and (pas_checked)):
            if (field_to_add not in field_names):
                field = QgsField( field_to_add, QVariant.String )
                layer.addAttribute( field )
            elif (field_to_add in field_names) and czy_kasowac:
                fieldid = layer.fields().lookupField(field_to_add)
                layer.deleteAttributes([fieldid])
                field = QgsField( field_to_add, QVariant.String )
                layer.addAttribute( field )
                layer.updateFields()
            else:
                error=field_to_add

    def addFields(self, km_checked, os_checked, pas_checked, czy_kasowac, czy_oceny):
        error = 0
        #czy poligon-------------
        for layer_klasa in self.new_layers:
            fields_to_add = {'os':['strona', 'km', 'dist_od_osi'], 
                             'pas': ['dist_od_pasa', 'czy_przecina'], 
                             'poligon': ['powierzchnia'],
                             'poligon_pas': [ 'pow_prze', 'procent'], 
                             'poligon_pas_ocena': ['ocena_real', 'ocena_eksp', 'czy_pypec']}
            
            layer = layer_klasa.getLayer()
            # layer_orygin
            polygon = layer_klasa.czyPolygon()
            #dodaje atrybuty ze źródłowej warstwy
            attr = layer.dataProvider().fields().toList()

            field_names = layer.fields().names()
            field_names = [each_string.lower() for each_string in field_names]

            layer.startEditing() #zaczynam edycję warstwy

            #dodaję pola jeśli nie ma w warstwie
            if 'id' not in field_names:
                field = QgsField( 'id', QVariant.String )
                layer.addAttribute( field )
            else:
                error=0
            idx_id = layer.fields().lookupField('id') #pobierz id koolumny żeby później uzupełnić


            for field in fields_to_add['os']:
                self.dodajPole('os', km_checked, os_checked, pas_checked, field_names, field, czy_kasowac, layer)
            for field in fields_to_add['pas']:
                self.dodajPole('pas', km_checked, os_checked, pas_checked, field_names, field, czy_kasowac, layer)
            for field in fields_to_add['poligon']:
                self.dodajPole('poligon', km_checked, os_checked, pas_checked, field_names, field, czy_kasowac, layer)
            for field in fields_to_add['poligon_pas']:
                self.dodajPole('poligon_pas', km_checked, os_checked, pas_checked, field_names, field, czy_kasowac, layer)
            if czy_oceny:
                for field in fields_to_add['poligon_pas_ocena']:
                    self.dodajPole('poligon_pas_ocena', km_checked, os_checked, pas_checked, field_names, field, czy_kasowac, layer)

            id2=0
            for f in layer.getFeatures():
                id2+=1
                f[idx_id] = str(id2)
                layer.updateFeature( f )
            layer.commitChanges()

        return error

class ZlaczWarianty:
    def __init__(self, paths_and_prefix):
        self.prefix = []
        self.paths = []
        # self_warstwyzlaczone = []
        for pex in paths_and_prefix:
            self.prefix.append(pex[1])
            self.paths.append(pex[0])

        self.output_path = QgsProcessing.TEMPORARY_OUTPUT

        self.results = {}
        self.outputs = {}


    def mergeLayers(self, output):
        path1 = None
        path2 = None
        i = 0
        context = QgsProcessingContext()
        for path in self.paths:
            i+=1
            if i == len(self.paths):
                self.output_path = output
            if path1 is not None and path2 is not None:
                path2 = path
                path1 = self.outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']
            if path2 is None and path1 is not None:
                path2 = path
            if path1 is None:
                path1 = path

            input1 = None
            if path1 is not None and path2 is not None:
                if i<3:
                    wariant_fieldname = str(i-1) + ''+ 'wariant'

                    # Kalkulator pól
                    alg_params = {
                        'FIELD_LENGTH': 200,
                        'FIELD_NAME': wariant_fieldname,
                        'FIELD_PRECISION': 0,
                        'FIELD_TYPE': 2,  # tekst
                        'FORMULA': "'" + self.prefix[i-2].replace('_','') + "'",
                        'INPUT': path1,
                        'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                    }
                    self.outputs['KalkulatorPl1'] = processing.run('native:fieldcalculator', alg_params, context=context, is_child_algorithm=True)
                    input1 = self.outputs['KalkulatorPl1']['OUTPUT']

                else:
                    input1 = self.outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']

                # Kalkulator pól
                alg_params = {
                    'FIELD_LENGTH': 200,
                    'FIELD_NAME': wariant_fieldname,
                    'FIELD_PRECISION': 0,
                    'FIELD_TYPE': 2,  # tekst
                    'FORMULA': "'" + self.prefix[i-1].replace('_','') + "'",
                    'INPUT': path2,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                }
                self.outputs['KalkulatorPl2'] = processing.run('native:fieldcalculator', alg_params, context=context, is_child_algorithm=True)

                alg_params = {
                    'DISCARD_NONMATCHING': False,
                    'FIELD': 'id',
                    'FIELDS_TO_COPY': ['strona', 'km', 'dist_od_os', 'dist_od_pa', 'czy_przeci','powierzchn', 'pow_prze', 'procent', wariant_fieldname],
                    'FIELD_2': 'id',
                    'INPUT': input1,
                    'INPUT_2': self.outputs['KalkulatorPl2']['OUTPUT'],
                    'METHOD': 1,  # przyjmuj atrybuty tylko z pierwszego pasującego obiektu (jeden do jednego)
                    'PREFIX': i,
                    'OUTPUT': self.output_path
                }
                # print( self.output_path)
                self.outputs['ZczAtrybutyWedugWartociPola'] = processing.run('native:joinattributestable', alg_params, context=context, is_child_algorithm=True)

        self.results['Wynik'] = self.outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']

        return self.results['Wynik']

class ObrobkaWarstw:
    def __init__(self):
        self.prefix = []
        self.paths = []
        #self.conte

    def dodaj_atrybut_z_warstwy(self, layer_info, fieldname, layerpath, context = QgsProcessingContext()):
        # Kalkulator pól
        outputs = {}

        # Przelicz układ współrzędnych warstwy
        alg_params = {
            'INPUT': layer_info,
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:2180'),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PrzeliczUkadWsprzdnychWarstwy'] = processing.runAndLoadResults('native:reprojectlayer', alg_params, context=context)

        alg_params = {
            'FIELD_LENGTH': 255,
            'FIELD_NAME': 'pole_dod',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # tekst
            'FORMULA': ''' overlay_nearest( layer:=\'{lay}\', expression:=\"{fieldname}\")[0]'''.format(lay = outputs['PrzeliczUkadWsprzdnychWarstwy']['OUTPUT'], fieldname = fieldname),
            'INPUT': layerpath,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        #print(alg_params['FORMULA'])
        outputs['KalkulatorPl'] = processing.run('native:fieldcalculator', alg_params, context=context, is_child_algorithm=True)
        return [context, outputs['KalkulatorPl']['OUTPUT']]


class OcenyPlatow:
    def __init__(self):
        self.prefix = []
        self.paths = []
        self.baza = []
        #self.conte
    #-----------------------------------------------------------------------
    def baza_do_ocen(self, baza_path):
        self.baza = []
        rekord = {
            'ogolne': ['siedlisko', 'pow_min', 'pow_max'], 
            'budowa': ['bufor_oddz'], 
            'eksploatacja': ['bufor_oddz',], 
            'FV': {'brzeg':[], 'srodek':[]}, 
            'U1': {'brzeg':[], 'srodek':[]}, 
            'U2': {'brzeg':[], 'srodek':[]}, 
            }

        with open(baza_path, newline='') as csvfile:
            spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
            for row in spamreader:
                rekord = {
                'ogolne': [row[0], row[1], row[2]], 
                'budowa': row[3], 
                'eksploatacja': [row[22], row[23], row[24]],
                'FV': {'brzeg':[row[4],row[5],row[6]], 'srodek':[row[7],row[8],row[9]]}, 
                'U1': {'brzeg':[row[10],row[11],row[12]], 'srodek':[row[13],row[14],row[15]]}, 
                'U2': {'brzeg':[row[16],row[17],row[18]], 'srodek':[row[19],row[20],row[21]]}, 
                }
                self.baza.append(rekord) 
        return self.baza


    def miejsce_przeciecia(self, warstwa, id, warstwa_inwestycja, context = QgsProcessingContext()):

        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        outputs = {}

        # Napraw geometrie
        alg_params = {
            'INPUT': warstwa,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['NaprawGeometrie'] = processing.run('native:fixgeometries', alg_params, context=context,  is_child_algorithm=True)

        # Agreguj
        alg_params = {
            'FIELD': ['{id}'.format(id=id)],
            'INPUT': outputs['NaprawGeometrie']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Agreguj'] = processing.run('native:dissolve', alg_params, context=context,  is_child_algorithm=True)

        # Otoczka
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 1e-06,
            'END_CAP_STYLE': 0,  # zaokrąglony
            'INPUT': outputs['Agreguj']['OUTPUT'],
            'JOIN_STYLE': 0,  # zaokrąglony
            'MITER_LIMIT': 2,
            'SEGMENTS': 55,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Otoczka'] = processing.run('native:buffer', alg_params, context=context,  is_child_algorithm=True)

        # Kalkulator pól
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'area',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 0,  # liczba zmiennoprzecinkowa
            'FORMULA': '$area',
            'INPUT': outputs['Otoczka']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl'] = processing.run('native:fieldcalculator', alg_params, context=context,  is_child_algorithm=True)

        # Różnica
        alg_params = {
            'INPUT': outputs['KalkulatorPl']['OUTPUT'],
            'OVERLAY': warstwa_inwestycja,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Rnica'] = processing.run('native:difference', alg_params, context=context,  is_child_algorithm=True)

        # Rozbij geometrie typu multipart na jednoczęściowe
        alg_params = {
            'INPUT': outputs['Rnica']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RozbijGeometrieTypuMultipartNaJednoczciowe'] = processing.run('native:multiparttosingleparts', alg_params, context=context,  is_child_algorithm=True)

        # Kalkulator pól 1
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'area_plat',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 0,  # liczba zmiennoprzecinkowa
            'FORMULA': '$area',
            'INPUT': outputs['RozbijGeometrieTypuMultipartNaJednoczciowe']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl1'] = processing.run('native:fieldcalculator', alg_params, context=context,  is_child_algorithm=True)

        # Kalkulator pól 2
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'procent_plat',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 0,  # liczba zmiennoprzecinkowa
            'FORMULA': '"area_plat"/"area"*100',
            'INPUT': outputs['KalkulatorPl1']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl2'] = processing.run('native:fieldcalculator', alg_params, context=context,  is_child_algorithm=True)

        # Kalkulator pól 3
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'liczba_pl',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # liczba całkowita
            'FORMULA': ' count( \"{id}\", group_by:=\"{id}\")'.format(id=id),
            'INPUT': outputs['KalkulatorPl2']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl3'] = processing.run('native:fieldcalculator', alg_params, context=context,  is_child_algorithm=True)

        # Kalkulator pól 4
        alg_params = {
            'FIELD_LENGTH': 255,
            'FIELD_NAME': 'gdzie',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 2,  # tekst
            'FORMULA': 'case when "liczba_pl"=1 and "procent_plat"=100 then \'nie przecina\' else \r\ncase when "liczba_pl"=1 and "procent_plat"<100 then \'kantem\' else \'przecina\' end end ',
            'INPUT': outputs['KalkulatorPl3']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl4'] = processing.run('native:fieldcalculator', alg_params, context=context,  is_child_algorithm=True)

        # Złącz atrybuty według wartości pola
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': id,
            'FIELDS_TO_COPY': [ 'area_plat', 'gdzie'],
            'FIELD_2': id,
            'INPUT': outputs['NaprawGeometrie']['OUTPUT'],
            'INPUT_2': outputs['KalkulatorPl4']['OUTPUT'],
            'METHOD': 1,  # przyjmuj atrybuty tylko z pierwszego pasującego obiektu (jeden do jednego)
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ZczAtrybutyWedugWartociPola'] = processing.run('native:joinattributestable', alg_params, context=context, is_child_algorithm=True)

        return [context, outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']]# outputs['KalkulatorPl4']['OUTPUT']]

    def licz_pow_pypci(self, layerpath, pole_siedlisko, pole_id, context = QgsProcessingContext()):
        # Kalkulator pól
        stringformula = ''
        i=0
        for rekord in self.baza:
            stringformula += 'case when \"{pole_siedlisko}\" = \'{siedlisko_z_bazy}\' then "pow_prze" + sum("area_plat", group_by:=\"{id}\", filter:=\"area_plat\"<{powmin_z_bazy} and \"pow_prze\">0) '.format(pole_siedlisko = pole_siedlisko, id=pole_id, siedlisko_z_bazy = rekord['ogolne'][0], powmin_z_bazy = rekord['ogolne'][1] )
            i+=1
            if i!= len(self.baza):
                stringformula += 'else '
            else:
                stringformula += 'else "pow_prze" '
                for z in range(0,i):
                    stringformula += 'end '
            #print(stringformula)
        outputs = {}
        alg_params = {
            'FIELD_LENGTH': 10,
            'FIELD_NAME': 'pow_pypcie',
            'FIELD_PRECISION': 3,
            'FIELD_TYPE': 0,  # liczba całkowita
            'FORMULA': stringformula, #'"pow_prze" + sum("area_plat", group_by:="id", filter:="area_plat"<1000 and "pow_prze">0)',
            'INPUT': layerpath,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl'] = processing.run('native:fieldcalculator', alg_params, context=context, is_child_algorithm=True)

        # Agreguj
        alg_params = {
            'FIELD': ['id'],
            'INPUT': outputs['KalkulatorPl']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Agreguj'] = processing.run('native:dissolve', alg_params, context=context, is_child_algorithm=True)
        return [context, outputs['Agreguj']['OUTPUT']]

    def licz_oceny(self, layerpath, pole_id, pole_rodzinw, pole_siedlisko, pole_stanzach, context = QgsProcessingContext()):
        def give_siedlisko_number_from_base(self, siedlisko):
            i=0
            for rekord in self.baza:
                if rekord['ogolne'][0] == siedlisko:
                    return i
                i+=1
            print(siedlisko)
            return -1

        outputs = {}

        # Kalkulator pól
        layer = QgsProcessingUtils.mapLayerFromString(layerpath, context)

        layer.startEditing()

        idx_siedlisko = layer.fields().lookupField(pole_siedlisko)
        idx_stanzach = layer.fields().lookupField(pole_stanzach)
        idx_pow_pypcie = layer.fields().lookupField('pow_pypcie')
        idx_pow_przeciec = layer.fields().lookupField('pow_prze')
        idx_gdzie = layer.fields().lookupField('gdzie')
        idx_powierzchnia = layer.fields().lookupField('powierzchnia')
        idx_procent = layer.fields().lookupField('procent')
        idx_dist_od_pa = layer.fields().lookupField('dist_od_pasa')
        idx_ocena_real = layer.fields().lookupField('ocena_real')
        idx_ocena_eksp = layer.fields().lookupField('ocena_eksp')
        idx_czy_pypec = layer.fields().lookupField('czy_pypec')
        #idx_rodzinw = layer.fields().lookupField(pole_rodzinw)
        idx_id = layer.fields().lookupField(pole_id)

        layer_feats = [ feat for feat in layer.getFeatures() ]
        for feat in layer_feats:
            siedlisko = feat[idx_siedlisko]
            stanzach  = feat[idx_stanzach]
            pow_pypcie = float(feat[idx_pow_pypcie])
            pow_przeciec = float(feat[idx_pow_przeciec])
            powierzchnia_plata = float(feat[idx_powierzchnia])
            gdzie = feat[idx_gdzie]
            procent = float(feat[idx_procent])
            rodzinw = pole_rodzinw
            dist_od_pa = float(feat[idx_dist_od_pa])
            id = feat[idx_id]

            siedlisko_number = give_siedlisko_number_from_base(self, siedlisko)
            print(siedlisko_number)
            if self.baza[siedlisko_number]['budowa'] == 'indywidualna' and procent>0:
                feat[idx_ocena_real] = 'ocena indyw.'
                feat[idx_ocena_eksp] = 'ocena indyw.'
                if not gdzie:
                    feat[idx_gdzie] = 'calosc'
                layer.updateFeature( feat )
            else:
                if str(stanzach).find('FV'):
                    stanzach_popr = 'FV'
                elif str(stanzach).find('U1'):
                    stanzach_popr = 'U1'
                elif  str(stanzach).find('U2'):
                    stanzach_popr = 'U2'
                else:
                    stanzach_popr = 'FV'

                if gdzie == 'przecina':
                    miejsce = 'srodek'
                elif gdzie == 'kantem':
                    miejsce = 'brzeg'
                elif gdzie == 'nie przecina':
                    miejsce = 'brak'
                else:
                    miejsce = 'srodek'

                if miejsce != 'brak':
                    proc1 = float(self.baza[siedlisko_number][stanzach_popr][miejsce][0])
                    proc2 = float(self.baza[siedlisko_number][stanzach_popr][miejsce][1])
                else:
                    proc1 = 0
                    proc2 = 0
                try:
                    bufor_real = float(self.baza[siedlisko_number]['budowa'])
                except:
                    bufor_real = 0

                procent_z_pypciami = pow_pypcie*100/powierzchnia_plata

                if procent_z_pypciami <= 0 and dist_od_pa > bufor_real:
                    ocena_realizacja = 0
                elif procent_z_pypciami <= 0 and dist_od_pa <= bufor_real:
                    ocena_realizacja = -1
                elif (procent_z_pypciami < proc1):
                    ocena_realizacja = -1
                elif procent_z_pypciami < proc2:
                    ocena_realizacja = -2
                else:
                    ocena_realizacja = -3

                feat[idx_ocena_real] = ocena_realizacja
                feat[idx_czy_pypec] = 'x' if pow_pypcie != pow_przeciec else None
                if not gdzie:
                    feat[idx_gdzie] = 'calosc'

                bufor_eksplo = float(self.baza[siedlisko_number]['eksploatacja'][0])
                ocena_eksp_jesli_przecina = float(self.baza[siedlisko_number]['eksploatacja'][1])
                ocena_eksp_jesli_w_buforze = float(self.baza[siedlisko_number]['eksploatacja'][2])

                if procent > 0:
                    ocena_eksploatacja = ocena_eksp_jesli_przecina
                elif dist_od_pa <= bufor_eksplo:
                    ocena_eksploatacja = ocena_eksp_jesli_w_buforze
                else:
                    ocena_eksploatacja = 0

                feat[idx_ocena_eksp] = ocena_eksploatacja

                layer.updateFeature( feat )
        layer.commitChanges()

        # Przelicz układ współrzędnych warstwy
        alg_params = {
            'INPUT': layer,
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:2180'),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PrzeliczUkadWsprzdnychWarstwy'] = processing.run('native:reprojectlayer', alg_params, context=context, is_child_algorithm=True)

        return [context, outputs['PrzeliczUkadWsprzdnychWarstwy']['OUTPUT']]