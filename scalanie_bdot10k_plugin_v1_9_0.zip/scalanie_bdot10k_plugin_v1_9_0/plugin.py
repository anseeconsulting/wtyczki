import os
import re
import shutil
import tempfile
import time
import zipfile

from qgis.PyQt.QtCore import Qt, QTimer, QObject, QThread, pyqtSignal
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
)

from qgis.core import QgsProject, QgsVectorLayer
from qgis import processing

try:
    import rarfile
except Exception:
    rarfile = None



class MergeWorker(QObject):
    progress_update = pyqtSignal(int, str)
    log_message = pyqtSignal(str)
    completed = pyqtSignal(str)
    error_message = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, input_folder: str, output_file: str, selected_layers: list[str], parent=None):
        super().__init__(parent)
        self.input_folder = input_folder
        self.output_file = output_file
        self.selected_layers = selected_layers
        self.temp_dir = None

    def log(self, message: str):
        self.log_message.emit(message)

    def update_global_progress(self, stage_start: int, stage_size: int, completed: int, total: int, stage: str):
        if total <= 0:
            percent = stage_start
        else:
            percent = stage_start + (completed / total) * stage_size
        percent = max(0, min(100, int(percent)))
        self.progress_update.emit(percent, stage)

    def _archive_paths(self, input_folder: str):
        return [
            os.path.join(root, name)
            for root, _dirs, files in os.walk(input_folder)
            for name in files
            if name.lower().endswith((".zip", ".rar"))
        ]

    def _direct_data_paths(self, input_folder: str):
        return [
            os.path.join(root, name)
            for root, _dirs, files in os.walk(input_folder)
            for name in files
            if name.lower().endswith((".shp", ".gpkg"))
        ]

    def _list_archive_members(self, archive_path: str):
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                return zf.namelist()
        if lower.endswith(".rar"):
            if rarfile is None:
                raise ValueError("Obsługa RAR nie jest dostępna: brakuje biblioteki rarfile.")
            try:
                with rarfile.RarFile(archive_path, "r") as rf:
                    return rf.namelist()
            except Exception as exc:
                raise ValueError(
                    "Nie udało się odczytać archiwum RAR. "
                    "Sprawdź, czy w systemie jest dostępny WinRAR, UnRAR albo 7-Zip. "
                    f"Szczegóły: {exc}"
                )
        return []

    def _extract_member(self, archive_path: str, member: str, target_dir: str):
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extract(member, target_dir)
            return
        if lower.endswith(".rar"):
            if rarfile is None:
                raise ValueError("Obsługa RAR nie jest dostępna: brakuje biblioteki rarfile.")
            try:
                with rarfile.RarFile(archive_path, "r") as rf:
                    rf.extract(member, target_dir)
            except Exception as exc:
                raise ValueError(
                    "Nie udało się wypakować pliku z archiwum RAR. "
                    "Sprawdź, czy w systemie jest dostępny WinRAR, UnRAR albo 7-Zip. "
                    f"Szczegóły: {exc}"
                )

    def _find_extracted_file(self, base_name: str, extension: str):
        target_name = base_name + extension
        if not self.temp_dir:
            return None
        for root, _dirs, files in os.walk(self.temp_dir):
            if target_name in files:
                return os.path.join(root, target_name)
        return None

    def _normalize_layer_code(self, layer_code: str) -> str:
        return re.sub(r"_\d+$", "", layer_code.upper())

    def _extract_bdot_layer_code(self, text: str) -> str | None:
        upper_text = text.upper()
        match = re.search(r"(?:^|__)(OT_[A-Z0-9]+_(?:P|L|A)(?:_\d+)?)$", upper_text)
        if match:
            return match.group(1)
        return None

    def _layer_matches(self, text: str, selected_layers: list[str]) -> bool:
        layer_code = self._extract_bdot_layer_code(text)
        if not layer_code:
            return False
        normalized_found = self._normalize_layer_code(layer_code)
        normalized_selected = {self._normalize_layer_code(layer) for layer in selected_layers}
        return normalized_found in normalized_selected

    def _matching_gpkg_layers(self, gpkg_path: str, selected_layers: list[str], extracted: bool = False):
        found_uris = []
        container_layer = QgsVectorLayer(gpkg_path, os.path.basename(gpkg_path), "ogr")
        if not container_layer.isValid():
            self.log(f"  Nie udało się otworzyć GPKG: {os.path.basename(gpkg_path)}")
            return found_uris

        normalized_selected = {self._normalize_layer_code(layer) for layer in selected_layers}
        sublayers = container_layer.dataProvider().subLayers()
        for sublayer_def in sublayers:
            parts = sublayer_def.split("!!::!!")
            sublayer_name = parts[1] if len(parts) > 1 else sublayer_def
            sublayer_code = self._extract_bdot_layer_code(sublayer_name) or sublayer_name.upper()
            if self._normalize_layer_code(sublayer_code) in normalized_selected:
                uri = f"{gpkg_path}|layername={sublayer_name}"
                found_uris.append(uri)
                prefix = "Wypakowano GPKG" if extracted else "Znaleziono GPKG"
                self.log(f"  {prefix}: {os.path.basename(gpkg_path)} | {sublayer_name}")
        return found_uris

    def _extract_matching_from_archive(self, archive_path: str, selected_layers: list[str]):
        members = self._list_archive_members(archive_path)
        found_uris = []
        needed_shp_exts = {".shp", ".shx", ".dbf", ".prj", ".cpg"}

        shp_members = [m for m in members if m.lower().endswith(".shp")]
        gpkg_members = [m for m in members if m.lower().endswith(".gpkg")]

        for shp_member in shp_members:
            shp_base = os.path.splitext(os.path.basename(shp_member))[0]
            if not self._layer_matches(shp_base, selected_layers):
                continue

            for member in members:
                member_base = os.path.splitext(os.path.basename(member))[0]
                member_ext = os.path.splitext(member)[1].lower()
                if member_base == shp_base and member_ext in needed_shp_exts:
                    self._extract_member(archive_path, member, self.temp_dir)

            shp_path = self._find_extracted_file(shp_base, ".shp")
            if shp_path:
                found_uris.append(shp_path)
                self.log(f"  Wypakowano SHP: {os.path.basename(shp_path)}")

        for gpkg_member in gpkg_members:
            gpkg_base = os.path.splitext(os.path.basename(gpkg_member))[0]
            self._extract_member(archive_path, gpkg_member, self.temp_dir)
            gpkg_path = self._find_extracted_file(gpkg_base, ".gpkg")
            if not gpkg_path:
                continue

            found_uris.extend(self._matching_gpkg_layers(gpkg_path, selected_layers, extracted=True))

        return found_uris

    def _matching_direct_sources(self, input_folder: str, selected_layers: list[str]):
        found_uris = []
        direct_paths = self._direct_data_paths(input_folder)
        if direct_paths:
            self.log(f"Znaleziono bezpośrednie pliki SHP/GPKG: {len(direct_paths)}")

        for path in direct_paths:
            lower = path.lower()
            base = os.path.splitext(os.path.basename(path))[0]

            if lower.endswith(".shp"):
                if self._layer_matches(base, selected_layers):
                    found_uris.append(path)
                    self.log(f"  Znaleziono SHP: {os.path.basename(path)}")
            elif lower.endswith(".gpkg"):
                found_uris.extend(self._matching_gpkg_layers(path, selected_layers, extracted=False))

        return found_uris

    def collect_matching_layers(self, input_folder: str, selected_layers: list[str]):
        archives = self._archive_paths(input_folder)
        direct_uris = self._matching_direct_sources(input_folder, selected_layers)

        if not archives and not direct_uris:
            raise ValueError(
                "W podanym folderze nie znaleziono archiwów ZIP/RAR ani plików SHP/GPKG."
            )

        self.update_global_progress(5, 5, 1, 1, "Przygotowanie")
        found_layer_uris = list(direct_uris)

        if direct_uris:
            self.log(f"Znaleziono bezpośrednie źródła danych: {len(direct_uris)}")

        if archives:
            self.log(f"Znaleziono archiwa: {len(archives)}")
            self.temp_dir = tempfile.mkdtemp(prefix="bdot_merge_")
            self.log(f"Katalog tymczasowy: {self.temp_dir}")

            archive_count = len(archives)
            for index, archive_path in enumerate(archives, start=1):
                archive_name = os.path.basename(archive_path)
                self.update_global_progress(10, 40, index - 1, archive_count, "Skanowanie archiwów")
                self.log(f"Przetwarzanie archiwum: {archive_name}")
                try:
                    archive_uris = self._extract_matching_from_archive(archive_path, selected_layers)
                    if archive_uris:
                        found_layer_uris.extend(archive_uris)
                    else:
                        self.log("  Brak pasujących warstw w tym archiwum.")
                except Exception as exc:
                    self.log(f"  Błąd: {exc}")
                self.update_global_progress(10, 40, index, archive_count, "Skanowanie archiwów")
        else:
            self.update_global_progress(10, 40, 1, 1, "Skanowanie danych")

        unique_uris = []
        seen = set()
        for uri in found_layer_uris:
            if uri not in seen:
                unique_uris.append(uri)
                seen.add(uri)

        if not unique_uris:
            raise ValueError("Nie znaleziono wybranych warstw w podanym folderze.")

        self.update_global_progress(50, 0, 0, 1, "Zakończono wyszukiwanie danych")
        return unique_uris

    def _warstwa_value_from_name(self, name: str) -> str:
        upper_name = name.upper()
        match = re.search(r"(?:^|__)OT_([A-Z0-9]+)_(?:P|L|A)(?:_\d+)?$", upper_name)
        if match:
            return match.group(1)

        if upper_name.startswith("OT_"):
            upper_name = upper_name[3:]
        parts = upper_name.split("_")
        if parts:
            return parts[0]
        return upper_name

    def _prepare_layer_with_warstwa_field(self, layer: QgsVectorLayer, source_name: str):
        warstwa_value = self._warstwa_value_from_name(source_name)
        self.log(f"  Dodawanie pola WARSTWA = {warstwa_value}")

        result = processing.run(
            "native:fieldcalculator",
            {
                "INPUT": layer,
                "FIELD_NAME": "WARSTWA",
                "FIELD_TYPE": 2,
                "FIELD_LENGTH": 20,
                "FIELD_PRECISION": 0,
                "FORMULA": f"'{warstwa_value}'",
                "OUTPUT": "memory:",
            },
        )

        prepared_layer = result["OUTPUT"]
        if not prepared_layer or not prepared_layer.isValid():
            raise ValueError(f"Nie udało się dodać pola WARSTWA dla warstwy {source_name}.")
        return prepared_layer

    def merge_layers(self, layer_uris, output_file: str):
        valid_layers = []
        prepare_total = len(layer_uris)

        for index, uri in enumerate(layer_uris, start=1):
            name = uri.split("|layername=")[-1] if "|layername=" in uri else os.path.splitext(os.path.basename(uri))[0]
            self.update_global_progress(50, 35, index - 1, prepare_total, "Przygotowanie warstw")

            layer = QgsVectorLayer(uri, name, "ogr")
            if not layer.isValid():
                self.log(f"Nie udało się wczytać warstwy: {uri}")
                self.update_global_progress(50, 35, index, prepare_total, "Przygotowanie warstw")
                continue

            self.log(f"Wczytano warstwę: {name}, liczba obiektów: {layer.featureCount()}")
            prepared_layer = self._prepare_layer_with_warstwa_field(layer, name)
            self.log(f"Po dodaniu pola WARSTWA: {prepared_layer.featureCount()} obiektów")
            valid_layers.append(prepared_layer)
            self.update_global_progress(50, 35, index, prepare_total, "Przygotowanie warstw")

        if not valid_layers:
            raise ValueError("Nie udało się wczytać żadnej poprawnej warstwy.")

        if not output_file.lower().endswith((".gpkg", ".shp")):
            output_file += ".gpkg"

        self.log(f"Liczba warstw do scalenia: {len(valid_layers)}")
        self.update_global_progress(85, 10, 0, 1, "Scalanie warstw")

        result = processing.run(
            "native:mergevectorlayers",
            {
                "LAYERS": valid_layers,
                "CRS": None,
                "OUTPUT": output_file,
            },
        )

        output_uri = result["OUTPUT"]
        layer_name = os.path.splitext(os.path.basename(output_file))[0]
        output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid() and output_file.lower().endswith(".gpkg"):
            output_uri = f"{output_file}|layername={layer_name}"
            output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid():
            raise ValueError("Nie udało się wczytać warstwy wynikowej po scaleniu.")

        output_layer.reload()
        self.log(f"Liczba zapisanych obiektów: {output_layer.featureCount()}")
        self.log("W warstwie wynikowej dodano pole WARSTWA z nazwą źródłowej klasy BDOT.")
        self.log(f"Plik wynikowy: {output_file}")
        self.update_global_progress(85, 10, 1, 1, "Scalanie warstw")
        return output_file

    def _cleanup_temp_dir(self):
        self.update_global_progress(95, 5, 0, 1, "Czyszczenie")
        if self.temp_dir and os.path.isdir(self.temp_dir):
            temp_dir_to_remove = self.temp_dir
            self.temp_dir = None
            try:
                shutil.rmtree(temp_dir_to_remove, ignore_errors=False)
                self.log(f"Usunięto pliki tymczasowe: {temp_dir_to_remove}")
            except Exception as exc:
                self.log(
                    f"Nie udało się usunąć plików tymczasowych: {temp_dir_to_remove}. Szczegóły: {exc}"
                )
        else:
            self.temp_dir = None
        self.update_global_progress(95, 5, 1, 1, "Zakończono")

    def run(self):
        try:
            self.update_global_progress(0, 5, 1, 1, "Rozpoczynanie")
            self.log('Wybrane warstwy (pełne kody): ' + ', '.join(self.selected_layers))
            layer_uris = self.collect_matching_layers(self.input_folder, self.selected_layers)
            output_file = self.merge_layers(layer_uris, self.output_file)
            self._cleanup_temp_dir()
            self.completed.emit(output_file)
        except Exception as exc:
            try:
                self._cleanup_temp_dir()
            except Exception:
                pass
            self.error_message.emit(str(exc))
        finally:
            self.finished.emit()


class BdotZipMergeDialog(QDialog):
    POINT_LAYERS = [
        "OT_ADMS_P",
        "OT_BUIT_P",
        "OT_BUTR_P",
        "OT_BUWT_P",
        "OT_BUZT_P",
        "OT_KUKO_P",
        "OT_KUPG_P",
        "OT_OIKM_P",
        "OT_OIOR_P",
        "OT_OIPR_P",
        "OT_RTPW_P",
        "OT_SKRW_P",
    ]

    LINE_LAYERS = [
        "OT_BUHD_L",
        "OT_BUIB_L",
        "OT_BUIN_L",
        "OT_BUSP_L",
        "OT_BUTR_L",
        "OT_BUUO_L",
        "OT_BUZM_L",
        "OT_OIKM_L",
        "OT_OIOR_L",
        "OT_OIPR_L",
        "OT_RTLW_L",
        "OT_SKDR_L",
        "OT_SKJZ_L",
        "OT_SKPP_L",
        "OT_SKRP_L",
        "OT_SKTR_L",
        "OT_SULN_L",
        "OT_SUPR_L",
        "OT_SWKN_L",
        "OT_SWRM_L",
        "OT_SWRS_L",
    ]

    POLYGON_LAYERS = [
        "OT_ADJA_A",
        "OT_ADMS_A",
        "OT_BUBD_A",
        "OT_BUBD_A_1",
        "OT_BUHD_A",
        "OT_BUIB_A",
        "OT_BUIT_A",
        "OT_BUSP_A",
        "OT_BUWT_A",
        "OT_BUZT_A",
        "OT_KUHO_A",
        "OT_KUHU_A",
        "OT_KUKO_A",
        "OT_KUMN_A",
        "OT_KUOS_A",
        "OT_KUOZ_A",
        "OT_KUPG_A",
        "OT_KUPW_A",
        "OT_KUSC_A",
        "OT_KUSK_A",
        "OT_KUZA_A",
        "OT_OIKM_A",
        "OT_OIMK_A",
        "OT_OIOR_A",
        "OT_OISZ_A",
        "OT_PTGN_A",
        "OT_PTKM_A",
        "OT_PTLZ_A",
        "OT_PTNZ_A",
        "OT_PTPL_A",
        "OT_PTRK_A",
        "OT_PTSO_A",
        "OT_PTTR_A",
        "OT_PTUT_A",
        "OT_PTWZ_A",
        "OT_PTZB_A",
        "OT_TCON_A",
        "OT_TCPK_A",
        "OT_TCPN_A",
        "OT_TCRZ_A",
    ]

    LAYER_LABELS = {('Poligon', 'ADJA'): 'ADJA - jednostki podziału administracyjnego', ('Poligon', 'ADMS'): 'ADMS - miejscowość', ('Poligon', 'BUBD'): 'BUBD - budynek', ('Poligon', 'BUHD'): 'BUHD - budowla hydrotechniczna', ('Poligon', 'BUIB'): 'BUIB - inna budowla', ('Poligon', 'BUIT'): 'BUIT - inne urządzenie techniczne', ('Poligon', 'BUSP'): 'BUSP - budowla sportowa', ('Poligon', 'BUWT'): 'BUWT - wysoka budowla techniczna', ('Poligon', 'BUZT'): 'BUZT - zbiornik techniczny', ('Poligon', 'KUHO'): 'KUHO - kompleks usług hotelarskich', ('Poligon', 'KUHU'): 'KUHU - bazar lub targowisko', ('Poligon', 'KUKO'): 'KUKO - kompleks komunikacyjny', ('Poligon', 'KUMN'): 'KUMN - osiedle mieszkaniowe', ('Poligon', 'KUOS'): 'KUOS - kompleks oświatowy', ('Poligon', 'KUOZ'): 'KUOZ - kompleks ochrony zdrowia i opieki społecznej', ('Poligon', 'KUPG'): 'KUPG - kompleks przemysłowo-gospodarczy', ('Poligon', 'KUPW'): 'KUPW - brak rozwinięcia skrótu w dokumencie', ('Poligon', 'KUSC'): 'KUSC - kompleks sakralny i cmentarz', ('Poligon', 'KUSK'): 'KUSK - kompleks sportowy i rekreacyjny', ('Poligon', 'KUZA'): 'KUZA - kompleks zabytkowo-historyczny', ('Poligon', 'OIKM'): 'OIKM - obiekt związany z komunikacją', ('Poligon', 'OIMK'): 'OIMK - mokradło', ('Poligon', 'OIOR'): 'OIOR - obiekt o znaczeniu orientacyjnym w terenie', ('Poligon', 'OISZ'): 'OISZ - szuwary', ('Poligon', 'PTGN'): 'PTGN - grunt nieużytkowany', ('Poligon', 'PTKM'): 'PTKM - teren komunikacyjny', ('Poligon', 'PTLZ'): 'PTLZ - teren leśny lub zadrzewiony', ('Poligon', 'PTNZ'): 'PTNZ - inny teren niezabudowany', ('Poligon', 'PTPL'): 'PTPL - plac', ('Poligon', 'PTRK'): 'PTRK - roślinność krzewiasta', ('Poligon', 'PTSO'): 'PTSO - składowisko odpadów', ('Poligon', 'PTTR'): 'PTTR - roślinność trawiasta i uprawa rolna', ('Poligon', 'PTUT'): 'PTUT - uprawa trwała', ('Poligon', 'PTWZ'): 'PTWZ - wyrobisko i zwałowisko', ('Poligon', 'PTZB'): 'PTZB - zabudowa', ('Poligon', 'TCON'): 'TCON - obszar Natura 2000', ('Poligon', 'TCPK'): 'TCPK - park krajobrazowy', ('Poligon', 'TCPN'): 'TCPN - park narodowy', ('Poligon', 'TCRZ'): 'TCRZ - rezerwat', ('Linia', 'BUHD'): 'BUHD - budowla hydrotechniczna', ('Linia', 'BUIB'): 'BUIB - inna budowla', ('Linia', 'BUIN'): 'BUIN - budowla inżynierska', ('Linia', 'BUSP'): 'BUSP - budowla sportowa', ('Linia', 'BUTR'): 'BUTR - urządzenie transportowe', ('Linia,BUUO,"umocnienie drogowe, kolejowe i wodne"', 'nan'): 'nan - nan', ('Linia', 'BUZM'): 'BUZM - budowla ziemna', ('Linia', 'OIKM'): 'OIKM - obiekt związany z komunikacją', ('Linia', 'OIOR'): 'OIOR - obiekt o znaczeniu orientacyjnym w terenie', ('Linia', 'OIPR'): 'OIPR - obiekt przyrodniczy', ('Linia', 'RTLW'): 'RTLW - linia wysokościowa', ('Linia', 'SKDR'): 'SKDR - droga', ('Linia', 'SKJZ'): 'SKJZ - jezdnia', ('Linia', 'SKPP'): 'SKPP - przeprawa', ('Linia', 'SKRP'): 'SKRP - ciąg ruchu pieszego lub rowerowego', ('Linia', 'SKTR'): 'SKTR - tor lub zespół torów', ('Linia', 'SULN'): 'SULN - linia elektroenergetyczna', ('Linia', 'SUPR'): 'SUPR - przewód rurowy', ('Linia', 'SWKN'): 'SWKN - kanał', ('Linia', 'SWRM'): 'SWRM - rów melioracyjny', ('Linia', 'SWRS'): 'SWRS - rzeka i strumień', ('Punkt', 'ADMS'): 'ADMS - miejscowość', ('Punkt', 'BUIT'): 'BUIT - inne urządzenie techniczne', ('Punkt', 'BUTR'): 'BUTR - urządzenie transportowe', ('Punkt', 'BUWT'): 'BUWT - wysoka budowla techniczna', ('Punkt', 'BUZT'): 'BUZT - zbiornik techniczny', ('Punkt', 'KUKO'): 'KUKO - kompleks komunikacyjny', ('Punkt', 'KUPG'): 'KUPG - kompleks przemysłowo-gospodarczy', ('Punkt', 'OIKM'): 'OIKM - obiekt związany z komunikacją', ('Punkt', 'OIOR'): 'OIOR - obiekt o znaczeniu orientacyjnym w terenie', ('Punkt', 'OIPR'): 'OIPR - obiekt przyrodniczy', ('Punkt', 'RTPW'): 'RTPW - punkt wysokościowy', ('Punkt', 'SKRW'): 'SKRW - rondo lub węzeł drogowy'}

    GEOMETRY_TO_LAYERS = {
        "Punkt": POINT_LAYERS,
        "Linia": LINE_LAYERS,
        "Poligon": POLYGON_LAYERS,
    }

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Scalanie BDOT10k")
        self.resize(860, 640)
        self.temp_dir = None
        self.start_time = None
        self.current_progress_percent = 0
        self.current_stage_text = "oczekiwanie"
        self.progress_timer = QTimer(self)
        self.progress_timer.setInterval(1000)
        self.progress_timer.timeout.connect(self.refresh_elapsed_time)
        self.worker_thread = None
        self.worker = None

        self.input_folder_edit = QLineEdit()
        self.input_folder_button = QPushButton("Przeglądaj…")
        self.input_folder_button.clicked.connect(self.choose_input_folder)

        self.geometry_combo = QComboBox()
        self.geometry_combo.addItem("-- wybierz --")
        self.geometry_combo.addItems(["Punkt", "Linia", "Poligon"])
        self.geometry_combo.currentIndexChanged.connect(self.update_layer_list)

        self.layer_list = QListWidget()
        self.layer_list.setMinimumHeight(240)
        self.layer_list.itemChanged.connect(self.update_run_button)

        self.layer_search_edit = QLineEdit()
        self.layer_search_edit.setPlaceholderText("Szukaj warstw...")
        self.layer_search_edit.textChanged.connect(self.filter_layer_list)

        self.select_all_button = QPushButton("Zaznacz wszystko")
        self.select_all_button.clicked.connect(self.select_all_layers)
        self.clear_selection_button = QPushButton("Odznacz wszystko")
        self.clear_selection_button.clicked.connect(self.clear_all_layers)
        self.selected_count_label = QLabel("Widoczne: 0 | Zaznaczone: 0")

        self.output_file_edit = QLineEdit()
        self.output_file_button = QPushButton("Zapisz jako…")
        self.output_file_button.clicked.connect(self.choose_output_file)

        self.add_to_project_checkbox = QCheckBox("Dodaj wynik do projektu")

        self.log_edit = QTextEdit()
        self.log_edit.setReadOnly(True)
        self.clear_log_button = QPushButton("Wyczyść logi")
        self.clear_log_button.clicked.connect(self.log_edit.clear)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_label = QLabel("Postęp: 0%")

        self.run_button = QPushButton("Uruchom")
        self.run_button.setEnabled(False)
        self.run_button.clicked.connect(self.run_merge)
        self.close_button = QPushButton("Zamknij")
        self.close_button.clicked.connect(self.close)

        self.setMinimumSize(980, 720)

        group_style = """
        QGroupBox {
            font-weight: bold;
            border: 1px solid #c7c7c7;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 10px;
            background: #f8f8f8;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 4px 0 4px;
        }
        """

        self.setStyleSheet(group_style)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(10, 10, 10, 10)

        input_group = QGroupBox("Dane wejściowe")
        input_group_layout = QVBoxLayout()
        input_group_layout.setSpacing(8)

        folder_label = QLabel("Wskaż folder z danymi w formacie ZIP/RAR")
        input_group_layout.addWidget(folder_label)

        input_layout = QHBoxLayout()
        input_layout.addWidget(self.input_folder_edit)
        input_layout.addWidget(self.input_folder_button)
        input_group_layout.addLayout(input_layout)

        input_group.setLayout(input_group_layout)
        main_layout.addWidget(input_group)

        center_layout = QGridLayout()
        center_layout.setHorizontalSpacing(10)
        center_layout.setVerticalSpacing(10)

        layers_group = QGroupBox("Wybór warstw")
        layers_group_layout = QVBoxLayout()
        layers_group_layout.setSpacing(8)

        geometry_label = QLabel("Typ geometrii")
        layers_group_layout.addWidget(geometry_label)
        layers_group_layout.addWidget(self.geometry_combo)

        layers_label = QLabel("Wybierz warstwy do scalenia")
        layers_group_layout.addWidget(layers_label)
        layers_group_layout.addWidget(self.layer_search_edit)
        layers_group_layout.addWidget(self.layer_list)

        layer_buttons = QHBoxLayout()
        layer_buttons.addWidget(self.select_all_button)
        layer_buttons.addWidget(self.clear_selection_button)
        layer_buttons.addStretch()
        layer_buttons.addWidget(self.selected_count_label)
        layers_group_layout.addLayout(layer_buttons)

        layers_group.setLayout(layers_group_layout)
        center_layout.addWidget(layers_group, 0, 0, 2, 1)

        result_group = QGroupBox("Wynik")
        result_group_layout = QVBoxLayout()
        result_group_layout.setSpacing(8)

        output_label = QLabel("Plik wynikowy")
        result_group_layout.addWidget(output_label)

        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_file_edit)
        output_layout.addWidget(self.output_file_button)
        result_group_layout.addLayout(output_layout)

        result_group_layout.addWidget(self.add_to_project_checkbox)

        progress_title = QLabel("Postęp")
        result_group_layout.addWidget(progress_title)
        result_group_layout.addWidget(self.progress_bar)
        result_group_layout.addWidget(self.progress_label)

        result_group.setLayout(result_group_layout)
        center_layout.addWidget(result_group, 0, 1)

        log_group = QGroupBox("Logi")
        log_group_layout = QVBoxLayout()
        log_group_layout.setSpacing(8)
        log_group_layout.addWidget(self.log_edit)

        log_buttons_layout = QHBoxLayout()
        log_buttons_layout.addWidget(self.clear_log_button)
        log_buttons_layout.addStretch()
        log_group_layout.addLayout(log_buttons_layout)

        log_group.setLayout(log_group_layout)
        center_layout.addWidget(log_group, 1, 1)

        center_layout.setColumnStretch(0, 3)
        center_layout.setColumnStretch(1, 2)

        main_layout.addLayout(center_layout)

        buttons_layout = QHBoxLayout()
        buttons_layout.addStretch()
        buttons_layout.addWidget(self.run_button)
        buttons_layout.addWidget(self.close_button)
        main_layout.addLayout(buttons_layout)

        self.setLayout(main_layout)
        self.update_layer_list()

    def log(self, message: str):
        self.log_edit.append(message)
        self.log_edit.ensureCursorVisible()
        QApplication.processEvents()


    def _display_layer_name(self, full_name: str) -> str:
        name = full_name
        if name.startswith("OT_"):
            name = name[3:]
        match = re.match(r"(.+?)_(P|L|A)(?:_\d+)?$", name)
        if match:
            base_name = match.group(1)
        else:
            base_name = name

        geometry_text = self.geometry_combo.currentText()
        return self.LAYER_LABELS.get((geometry_text, base_name), base_name)

    def _full_layer_names_for_display(self, display_name: str, geometry_text: str) -> list[str]:
        layers = self.GEOMETRY_TO_LAYERS.get(geometry_text, [])

        # display_name may be e.g. "ADJA - jednostki podziału administracyjnego"
        # or the fallback raw code.
        selected_base = display_name.split(" - ", 1)[0].strip()

        return [
            layer for layer in layers
            if self._display_layer_name(layer).split(" - ", 1)[0].strip() == selected_base
        ]

    def _selected_full_layer_names(self):
        selected = []
        seen = set()
        geometry_text = self.geometry_combo.currentText()

        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            if item.checkState() == Qt.Checked:
                display_name = item.data(Qt.UserRole)
                if not display_name:
                    continue
                for full_name in self._full_layer_names_for_display(str(display_name), geometry_text):
                    if full_name not in seen:
                        seen.add(full_name)
                        selected.append(full_name)

        return selected

    def _normalize_layer_code(self, layer_code: str) -> str:
        return re.sub(r"_\d+$", "", layer_code.upper())

    def _extract_bdot_layer_code(self, text: str) -> str | None:
        upper_text = text.upper()
        match = re.search(r"(?:^|__)(OT_[A-Z0-9]+_(?:P|L|A)(?:_\d+)?)$", upper_text)
        if match:
            return match.group(1)
        return None

    def _format_duration(self, seconds: float) -> str:
        seconds = max(0, int(seconds))
        hours, remainder = divmod(seconds, 3600)
        minutes, secs = divmod(remainder, 60)
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    def refresh_elapsed_time(self):
        elapsed = 0 if self.start_time is None else time.time() - self.start_time
        elapsed_text = self._format_duration(elapsed)
        self.progress_label.setText(
            f"Etap: {self.current_stage_text} — {self.current_progress_percent}% | Czas: {elapsed_text}"
        )
        QApplication.processEvents()

    def reset_progress(self):
        self.start_time = time.time()
        self.current_progress_percent = 0
        self.current_stage_text = "oczekiwanie"
        self.progress_bar.setValue(0)
        self.progress_label.setText("Etap: oczekiwanie — 0% | Czas: 00:00")
        self.progress_timer.start()
        QApplication.processEvents()

    def update_global_progress(self, stage_start: int, stage_size: int, completed: int, total: int, stage: str):
        if total <= 0:
            percent = stage_start
        else:
            percent = stage_start + (completed / total) * stage_size

        percent = max(0, min(100, int(percent)))
        self.current_progress_percent = percent
        self.current_stage_text = stage
        self.progress_bar.setValue(percent)
        self.refresh_elapsed_time()

    def choose_input_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Wybierz folder z danymi BDOT10k")
        if folder:
            self.input_folder_edit.setText(folder)

    def choose_output_file(self):
        start_dir = self.input_folder_edit.text().strip() or os.path.expanduser("~")
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Wybierz plik wynikowy",
            start_dir,
            "GeoPackage (*.gpkg);;Shapefile (*.shp)",
        )
        if path:
            self.output_file_edit.setText(path)


    def update_run_button(self):
        geometry_ok = self.geometry_combo.currentText() != "-- wybierz --"
        checked_count = sum(
            1 for i in range(self.layer_list.count())
            if not self.layer_list.item(i).isHidden() and self.layer_list.item(i).checkState() == Qt.Checked
        )
        visible_count = sum(
            1 for i in range(self.layer_list.count())
            if not self.layer_list.item(i).isHidden()
        )
        layers_ok = checked_count > 0
        self.run_button.setEnabled(geometry_ok and layers_ok)
        self.selected_count_label.setText(f"Widoczne: {visible_count} | Zaznaczone: {checked_count}")

    def filter_layer_list(self):
        search_text = self.layer_search_edit.text().strip().lower()

        for i in range(self.layer_list.count()):
            item = self.layer_list.item(i)
            item.setHidden(search_text not in item.text().lower())

        self.update_run_button()

    def update_layer_list(self):
        current_geometry = self.geometry_combo.currentText()

        self.layer_search_edit.clear()

        if current_geometry == "-- wybierz --":
            self.layer_list.clear()
            self.update_run_button()
            return

        layers = self.GEOMETRY_TO_LAYERS.get(current_geometry, [])
        self.layer_list.clear()

        unique_display_names = []
        seen = set()
        for layer_name in layers:
            display_name = self._display_layer_name(layer_name)
            if display_name not in seen:
                seen.add(display_name)
                unique_display_names.append(display_name)

        unique_display_names.sort(key=str.lower)

        for display_name in unique_display_names:
            item = QListWidgetItem(display_name)
            item.setData(Qt.UserRole, display_name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.layer_list.addItem(item)

        self.update_run_button()

    def select_all_layers(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.Checked)

    def clear_all_layers(self):
        for i in range(self.layer_list.count()):
            self.layer_list.item(i).setCheckState(Qt.Unchecked)

    def get_selected_layers(self):
        return self._selected_full_layer_names()

    def validate_inputs(self):
        input_folder = self.input_folder_edit.text().strip()
        output_file = self.output_file_edit.text().strip()
        selected_layers = self.get_selected_layers()

        if not input_folder:
            raise ValueError("Wskaż folder z danymi BDOT10k.")
        if not os.path.isdir(input_folder):
            raise ValueError("Wybrany folder nie istnieje.")
        if not output_file:
            raise ValueError("Wskaż plik wynikowy.")
        if not selected_layers:
            raise ValueError("Zaznacz co najmniej jedną warstwę.")

        parent_dir = os.path.dirname(output_file)
        if parent_dir and not os.path.isdir(parent_dir):
            raise ValueError("Folder docelowy dla pliku wynikowego nie istnieje.")

        return input_folder, output_file, selected_layers

    def _archive_paths(self, input_folder: str):
        return [
            os.path.join(root, name)
            for root, _dirs, files in os.walk(input_folder)
            for name in files
            if name.lower().endswith((".zip", ".rar"))
        ]

    def _direct_data_paths(self, input_folder: str):
        return [
            os.path.join(root, name)
            for root, _dirs, files in os.walk(input_folder)
            for name in files
            if name.lower().endswith((".shp", ".gpkg"))
        ]

    def _list_archive_members(self, archive_path: str):
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                return zf.namelist()
        if lower.endswith(".rar"):
            if rarfile is None:
                raise ValueError("Obsługa RAR nie jest dostępna: brakuje biblioteki rarfile.")
            try:
                with rarfile.RarFile(archive_path, "r") as rf:
                    return rf.namelist()
            except Exception as exc:
                raise ValueError(
                    "Nie udało się odczytać archiwum RAR. "
                    "Sprawdź, czy w systemie jest dostępny WinRAR, UnRAR albo 7-Zip. "
                    f"Szczegóły: {exc}"
                )
        return []

    def _extract_member(self, archive_path: str, member: str, target_dir: str):
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extract(member, target_dir)
            return
        if lower.endswith(".rar"):
            if rarfile is None:
                raise ValueError("Obsługa RAR nie jest dostępna: brakuje biblioteki rarfile.")
            try:
                with rarfile.RarFile(archive_path, "r") as rf:
                    rf.extract(member, target_dir)
            except Exception as exc:
                raise ValueError(
                    "Nie udało się wypakować pliku z archiwum RAR. "
                    "Sprawdź, czy w systemie jest dostępny WinRAR, UnRAR albo 7-Zip. "
                    f"Szczegóły: {exc}"
                )

    def _find_extracted_file(self, base_name: str, extension: str):
        target_name = base_name + extension
        if not self.temp_dir:
            return None
        for root, _dirs, files in os.walk(self.temp_dir):
            if target_name in files:
                return os.path.join(root, target_name)
        return None

    def _layer_matches(self, text: str, selected_layers: list[str]) -> bool:
        layer_code = self._extract_bdot_layer_code(text)
        if not layer_code:
            return False

        normalized_found = self._normalize_layer_code(layer_code)
        normalized_selected = {
            self._normalize_layer_code(layer)
            for layer in selected_layers
        }
        return normalized_found in normalized_selected

    def _extract_matching_from_archive(self, archive_path: str, selected_layers: list[str]):
        members = self._list_archive_members(archive_path)
        found_uris = []
        needed_shp_exts = {".shp", ".shx", ".dbf", ".prj", ".cpg"}

        shp_members = [m for m in members if m.lower().endswith(".shp")]
        gpkg_members = [m for m in members if m.lower().endswith(".gpkg")]

        for shp_member in shp_members:
            shp_base = os.path.splitext(os.path.basename(shp_member))[0]
            if not self._layer_matches(shp_base, selected_layers):
                continue

            for member in members:
                member_base = os.path.splitext(os.path.basename(member))[0]
                member_ext = os.path.splitext(member)[1].lower()
                if member_base == shp_base and member_ext in needed_shp_exts:
                    self._extract_member(archive_path, member, self.temp_dir)

            shp_path = self._find_extracted_file(shp_base, ".shp")
            if shp_path:
                found_uris.append(shp_path)
                self.log(f"  Wypakowano SHP: {os.path.basename(shp_path)}")

        for gpkg_member in gpkg_members:
            gpkg_base = os.path.splitext(os.path.basename(gpkg_member))[0]
            self._extract_member(archive_path, gpkg_member, self.temp_dir)
            gpkg_path = self._find_extracted_file(gpkg_base, ".gpkg")
            if not gpkg_path:
                continue

            found_uris.extend(self._matching_gpkg_layers(gpkg_path, selected_layers, extracted=True))

        return found_uris

    def _matching_gpkg_layers(self, gpkg_path: str, selected_layers: list[str], extracted: bool = False):
        found_uris = []
        container_layer = QgsVectorLayer(gpkg_path, os.path.basename(gpkg_path), "ogr")
        if not container_layer.isValid():
            self.log(f"  Nie udało się otworzyć GPKG: {os.path.basename(gpkg_path)}")
            return found_uris

        selected_upper = {layer.upper() for layer in selected_layers}
        sublayers = container_layer.dataProvider().subLayers()
        for sublayer_def in sublayers:
            parts = sublayer_def.split("!!::!!")
            sublayer_name = parts[1] if len(parts) > 1 else sublayer_def
            sublayer_code = self._extract_bdot_layer_code(sublayer_name) or sublayer_name.upper()
            if sublayer_code in selected_upper:
                uri = f"{gpkg_path}|layername={sublayer_name}"
                found_uris.append(uri)
                prefix = "Wypakowano GPKG" if extracted else "Znaleziono GPKG"
                self.log(f"  {prefix}: {os.path.basename(gpkg_path)} | {sublayer_name}")
        return found_uris

    def _matching_direct_sources(self, input_folder: str, selected_layers: list[str]):
        found_uris = []
        direct_paths = self._direct_data_paths(input_folder)
        if direct_paths:
            self.log(f"Znaleziono bezpośrednie pliki SHP/GPKG: {len(direct_paths)}")

        for path in direct_paths:
            lower = path.lower()
            base = os.path.splitext(os.path.basename(path))[0]

            if lower.endswith(".shp"):
                if self._layer_matches(base, selected_layers):
                    found_uris.append(path)
                    self.log(f"  Znaleziono SHP: {os.path.basename(path)}")
            elif lower.endswith(".gpkg"):
                found_uris.extend(self._matching_gpkg_layers(path, selected_layers, extracted=False))

        return found_uris

    def collect_matching_layers(self, input_folder: str, selected_layers: list[str]):
        archives = self._archive_paths(input_folder)
        direct_uris = self._matching_direct_sources(input_folder, selected_layers)

        if not archives and not direct_uris:
            raise ValueError(
                "W podanym folderze nie znaleziono archiwów ZIP/RAR ani plików SHP/GPKG."
            )

        self.update_global_progress(5, 5, 1, 1, "Przygotowanie")
        found_layer_uris = list(direct_uris)

        if direct_uris:
            self.log(f"Znaleziono bezpośrednie źródła danych: {len(direct_uris)}")

        if archives:
            self.log(f"Znaleziono archiwa: {len(archives)}")
            self.temp_dir = tempfile.mkdtemp(prefix="bdot_merge_")
            self.log(f"Katalog tymczasowy: {self.temp_dir}")

            archive_count = len(archives)
            for index, archive_path in enumerate(archives, start=1):
                archive_name = os.path.basename(archive_path)
                self.update_global_progress(10, 40, index - 1, archive_count, f"Skanowanie archiwów")
                self.log(f"Przetwarzanie archiwum: {archive_name}")
                try:
                    archive_uris = self._extract_matching_from_archive(archive_path, selected_layers)
                    if archive_uris:
                        found_layer_uris.extend(archive_uris)
                    else:
                        self.log("  Brak pasujących warstw w tym archiwum.")
                except Exception as exc:
                    self.log(f"  Błąd: {exc}")
                self.update_global_progress(10, 40, index, archive_count, f"Skanowanie archiwów")
        else:
            self.update_global_progress(10, 40, 1, 1, "Skanowanie danych")

        unique_uris = []
        seen = set()
        for uri in found_layer_uris:
            if uri not in seen:
                unique_uris.append(uri)
                seen.add(uri)

        if not unique_uris:
            raise ValueError("Nie znaleziono wybranych warstw w podanym folderze.")

        self.update_global_progress(50, 0, 0, 1, "Zakończono wyszukiwanie danych")
        return unique_uris

    def _warstwa_value_from_name(self, name: str) -> str:
        upper_name = name.upper()
        match = re.search(r"(?:^|__)OT_([A-Z0-9]+)_(?:P|L|A)(?:_\d+)?$", upper_name)
        if match:
            return match.group(1)

        if upper_name.startswith("OT_"):
            upper_name = upper_name[3:]

        parts = upper_name.split("_")
        if len(parts) >= 2:
            return parts[0]
        return upper_name

    def _prepare_layer_with_warstwa_field(self, layer: QgsVectorLayer, source_name: str):
        warstwa_value = self._warstwa_value_from_name(source_name)
        self.log(f"  Dodawanie pola WARSTWA = {warstwa_value}")

        result = processing.run(
            "native:fieldcalculator",
            {
                "INPUT": layer,
                "FIELD_NAME": "WARSTWA",
                "FIELD_TYPE": 2,
                "FIELD_LENGTH": 20,
                "FIELD_PRECISION": 0,
                "FORMULA": f"'{warstwa_value}'",
                "OUTPUT": "memory:",
            },
        )

        prepared_layer = result["OUTPUT"]
        if not prepared_layer or not prepared_layer.isValid():
            raise ValueError(f"Nie udało się dodać pola WARSTWA dla warstwy {source_name}.")
        return prepared_layer

    def merge_layers(self, layer_uris, output_file: str):
        valid_layers = []
        prepare_total = len(layer_uris)

        for index, uri in enumerate(layer_uris, start=1):
            name = uri.split("|layername=")[-1] if "|layername=" in uri else os.path.splitext(os.path.basename(uri))[0]
            self.update_global_progress(50, 35, index - 1, prepare_total, "Przygotowanie warstw")

            layer = QgsVectorLayer(uri, name, "ogr")
            if not layer.isValid():
                self.log(f"Nie udało się wczytać warstwy: {uri}")
                self.update_global_progress(50, 35, index, prepare_total, "Przygotowanie warstw")
                continue

            self.log(f"Wczytano warstwę: {name}, liczba obiektów: {layer.featureCount()}")
            prepared_layer = self._prepare_layer_with_warstwa_field(layer, name)
            self.log(f"Po dodaniu pola WARSTWA: {prepared_layer.featureCount()} obiektów")
            valid_layers.append(prepared_layer)
            self.update_global_progress(50, 35, index, prepare_total, "Przygotowanie warstw")

        if not valid_layers:
            raise ValueError("Nie udało się wczytać żadnej poprawnej warstwy.")

        if not output_file.lower().endswith((".gpkg", ".shp")):
            output_file += ".gpkg"
            self.output_file_edit.setText(output_file)

        self.log(f"Liczba warstw do scalenia: {len(valid_layers)}")
        self.update_global_progress(85, 10, 0, 1, "Scalanie warstw")

        result = processing.run(
            "native:mergevectorlayers",
            {
                "LAYERS": valid_layers,
                "CRS": None,
                "OUTPUT": output_file,
            },
        )

        output_uri = result["OUTPUT"]
        layer_name = os.path.splitext(os.path.basename(output_file))[0]
        output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid() and output_file.lower().endswith(".gpkg"):
            output_uri = f"{output_file}|layername={layer_name}"
            output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid():
            raise ValueError("Nie udało się wczytać warstwy wynikowej po scaleniu.")

        output_layer.reload()
        self.log(f"Liczba zapisanych obiektów: {output_layer.featureCount()}")
        self.log("W warstwie wynikowej dodano pole WARSTWA z nazwą źródłowej klasy BDOT.")
        self.log(f"Plik wynikowy: {output_file}")
        self.update_global_progress(85, 10, 1, 1, "Scalanie warstw")
        return output_layer

    def _cleanup_temp_dir(self):
        self.update_global_progress(95, 5, 0, 1, "Czyszczenie")
        if self.temp_dir and os.path.isdir(self.temp_dir):
            temp_dir_to_remove = self.temp_dir
            self.temp_dir = None
            try:
                shutil.rmtree(temp_dir_to_remove, ignore_errors=False)
                self.log(f"Usunięto pliki tymczasowe: {temp_dir_to_remove}")
            except Exception as exc:
                self.log(
                    f"Nie udało się usunąć plików tymczasowych: {temp_dir_to_remove}. Szczegóły: {exc}"
                )
        else:
            self.temp_dir = None
        self.update_global_progress(95, 5, 1, 1, "Zakończono")


    def on_worker_progress(self, percent: int, stage: str):
        self.current_progress_percent = percent
        self.current_stage_text = stage
        self.progress_bar.setValue(percent)
        self.refresh_elapsed_time()

    def on_worker_completed(self, output_file: str):
        layer_name = os.path.splitext(os.path.basename(output_file))[0]
        output_uri = output_file
        output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid() and output_file.lower().endswith(".gpkg"):
            output_uri = f"{output_file}|layername={layer_name}"
            output_layer = QgsVectorLayer(output_uri, layer_name, "ogr")

        if not output_layer.isValid():
            QMessageBox.critical(self, "Scalanie BDOT10k", "Nie udało się wczytać warstwy wynikowej po scaleniu.")
        else:
            if self.add_to_project_checkbox.isChecked():
                QgsProject.instance().addMapLayer(output_layer)
                self.log("Warstwa została dodana do projektu.")

            self.progress_timer.stop()
            self.refresh_elapsed_time()
            QMessageBox.information(self, "Scalanie BDOT10k", "Gotowe. Warstwy zostały scalone.")

        self.run_button.setEnabled(True)

    def on_worker_error(self, message: str):
        self.progress_timer.stop()
        self.refresh_elapsed_time()
        self.log(f"BŁĄD: {message}")
        QMessageBox.critical(self, "Scalanie BDOT10k", message)
        self.run_button.setEnabled(True)

    def on_worker_finished(self):
        if self.worker_thread is not None:
            self.worker_thread.quit()
            self.worker_thread.wait()
        self.worker_thread = None
        self.worker = None

    def run_merge(self):
        self.log_edit.clear()
        self.reset_progress()
        try:
            input_folder, output_file, selected_layers = self.validate_inputs()
        except Exception as exc:
            self.progress_timer.stop()
            QMessageBox.critical(self, "Scalanie BDOT10k", str(exc))
            return

        self.run_button.setEnabled(False)

        self.worker_thread = QThread(self)
        self.worker = MergeWorker(input_folder, output_file, selected_layers)
        self.worker.moveToThread(self.worker_thread)

        self.worker_thread.started.connect(self.worker.run)
        self.worker.log_message.connect(self.log)
        self.worker.progress_update.connect(self.on_worker_progress)
        self.worker.completed.connect(self.on_worker_completed)
        self.worker.error_message.connect(self.on_worker_error)
        self.worker.finished.connect(self.on_worker_finished)

        self.worker_thread.start()


class BdotZipMergePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")), "Scalanie BDOT10k", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&BDOT10k", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&BDOT10k", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        self.dialog = BdotZipMergeDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
